#!/bin/bash
#
#Kobi Biton: kobibito@amazon.lu
#Version 1.6
#21-Nov: Added a new function: userdata() , will create the userdata for the newly launched instance basically will populate the bucket and region name
#So all the other scripts will be able to use
#2015-09-28: fixed bug in the dermination of the ID variable
# Yet another script to start aws instance but this time integrates into chef-solo!
BUCKET=$(cat /home/ubuntu/.s3bucket)
REGION=$(cat /home/ubuntu/.region)
##Functions
function error_exit()
{

    echo "Fatal Error: $1 Will exit now"
    exit 1
}

function ok_cont()
{
    echo "$1"

}
cleanup()
{
rm -f /tmp/Newinstance
rm -f /tmp/stderr
}
usage()
{
cat << EOF

usage: $0 -a AMI-ID -s securityGroupID -k KeyPairName -i InstanceSize -n VPCsubnetID -m IAM-Instance-Profile(Arn=value) -c ChefRole

securityGroupID: The boostrapped instance Security Group Id, See the cloudformation output for the value of: ChefSoloInstanceSecurityGroupID
KeyPairName: Your keypair name, the public part will be pushed to the instance
InstanceSize: Any instance size
VPCsubnetID: The VPC Subnet Id to start the instance into, Subnet MUST BE PUBLIC and auto assign public IPs unless you plan to use VPN
IAM-Instance-Profile: The IAM Role that will be attached to The bootsteapped instance, See the cloudformation output for the value of: ChefSoloInstanceProfileArn
AMI-ID:  Only ubuntu based AMI's are supported !
ChefRole: Supported Roles are:  "base" or "web"



EOF
exit 1
}
while getopts “a:s:k:i:n::m:c:?” OPTION
do
     case $OPTION in
         a)
             AMIID=$OPTARG
             ;;
         s)
             SECGRPID=$OPTARG
             ;;
         k)
             KPNAME=$OPTARG
             ;;
         i)  
             INSTS=$OPTARG
             ;;  
         n)
             SBID=$OPTARG
             ;;
         m)  IAM=$OPTARG
             ;;
         c)  
             CHEFR=$OPTARG
             ;;
         ?)
             usage
             exit 1
             ;;
     esac
done

if [[ -z $AMIID ]] || [[ -z $SECGRPID ]] || [[ -z $KPNAME ]] || [[ -z $INSTS ]] || [[ -z $SBID ]] || [[ -z $IAM ]] || [[ -z $CHEFR ]]
then
     usage
     exit 1
fi
md5up()
{
  md5sum $1 | awk 'BEGIN { FS=" " };{ print $1 }' > "$1.md5"
  for i in "${PIPESTATUS[@]}"
              do
                if [ $i != 0 ];then
                  error_exit "Could not create solo.rb_$ID.md5 check error output"
                fi
            done
 return 0
}
userdata ()
{
 echo '#!/bin/bash' > ~/user-data.sh
 echo export BUCKET=$(cat /home/ubuntu/.s3bucket) >> ~/user-data.sh
 echo export REGION=$(cat /home/ubuntu/.region) >> ~/user-data.sh
 echo 'echo $BUCKET > /home/ubuntu/.s3bucket' >> ~/user-data.sh
 echo 'echo $REGION > /home/ubuntu/.region' >> ~/user-data.sh
 echo 'wget -O ~/bootstrap.sh https://$BUCKET.s3.amazonaws.com/others/bootstrap.sh' >> ~/user-data.sh
 echo 'cd ~' >> ~/user-data.sh
 echo 'chmod +x bootstrap.sh' >> ~/user-data.sh
 echo './bootstrap.sh' >> ~/user-data.sh
}
solo2s3 ()
{
cd ~
aws ec2 run-instances --image-id $AMIID --key-name $KPNAME --security-group-ids $SECGRPID \
        --instance-type $INSTS --subnet-id $SBID --user-data file://user-data.sh --iam-instance-profile $IAM --region $REGION --output text 1>/tmp/Newinstance 2>/tmp/stderr

ID=`grep INSTANCES /tmp/Newinstance | awk 'BEGIN {FS=" "};{ print $7 }'`
 if [ -z $ID ];then
    error_exit "Instance ID Returned An Empty String Check /tmp/stderr"
 fi
aws ec2 create-tags --resources $ID --tags Key=Name,Value=Chef-Solo-Bootstrapped --region $REGION
       ok_cont "Instance ID was: $ID, Generating Solo Configs.."
       ok_cont "Generating solo.rb_$ID..."
       sed "s/instanceid/$ID/g" solo.rb > solo.rb_$ID || error_exit "Could not generate solo.rb_$ID check stdout"
       md5up "solo.rb_$ID"
         if [ "$?" = "0" ];then
           ok_cont "Created md5 file named solo.rb_$ID.md5"
         else
           error_exit "Could not create solo.rb_$ID.md5"
         fi
       aws s3 cp solo.rb_$ID.md5 s3://$BUCKET/solorb/ --region $REGION || error_exit "Could not copy solo.rb_$ID.md5 to S3 Bucket check stdout"
       aws s3 cp solo.rb_$ID s3://$BUCKET/solorb/ --region $REGION || error_exit "Could not copy solo.rb_$ID to S3 Bucket check stdout"
       ok_cont "solo.rb_$ID & solo.rb_$ID.md5 Were Generated and Copied to S3 Bucket!"
       cp $1.json $ID.json || error_exit "Could not rename base.json to $ID.json check stdout"
       md5up "$ID.json"
        if [ "$?" = "0" ];then
           ok_cont "Created md5 file named $ID.json.md5"
         else
           error_exit "Could not create $ID.json.md5"
         fi
       aws s3 cp $ID.json.md5 s3://$BUCKET/nodejson/ --region $REGION || error_exit "Could not copy $ID.json.md5 to S3 Bucket check stdout"
       aws s3 cp $ID.json s3://$BUCKET/nodejson/ --region $REGION || error_exit "Could not copy $ID.json to S3 Bucket check stdout"
       ok_cont "$ID.json & $ID.json.md5 Were Generated and Copied to S3 Bucket!"
       ok_cont "You should be good to go now :-) bye"
       mv solo.rb_$ID solorb/ 
       mv solo.rb_$ID.md5 solorb/
       mv $ID.json nodejson/
       mv $ID.json.md5 nodejson/
       return 0
}
case $CHEFR in 
 
  base)
       userdata
       solo2s3 "base"
      ;; 
   web)
      userdata
      solo2s3 "web"
      ;;
  esac

#Lets Clean 
cleanup
exit 0
